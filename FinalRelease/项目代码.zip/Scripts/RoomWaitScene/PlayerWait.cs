using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Photon.Pun;

public class PlayerWait : MonoBehaviour
{
    [Header("--��Ҹ������--")]
    public GameObject PlayerOwnScene;
    public Text PlayerOwnNameText;
    public Text PlayerOwnReadyText;
    public bool hasReady = false;
    public int PlayerNum;
   // public RoomWaitManager waitmanager;
    [SerializeField] PhotonView pv;
    void Start()
    {
        pv = this.GetComponent<PhotonView>();
    }
    [PunRPC]
    public void EnterGame()
    {
        if (pv.IsMine)
        {
            PhotonNetwork.LoadLevel(2);
        }
        else
        {
            PhotonNetwork.LoadLevel(2);
        }
    }

    [PunRPC]
    public void ReadyButtonDeal()
    {
       
        // PlayerOwnReadyText.gameObject.SetActive(hasReady);
        
           if(pv.IsMine){
            hasReady = !hasReady;
            //GameObject.FindObjectOfType<RoomWaitManager>().PlayerOwnReadyText.gameObject.SetActive(hasReady);          
            PlayerOwnReadyText.gameObject.SetActive(hasReady);
           }
           else
           {
            //GameObject.FindObjectOfType<RoomWaitManager>().players[PlayerNum].PlayerOwnReadyText.gameObject
            if (GameObject.FindObjectOfType<RoomWaitManager>().players[PlayerNum].PlayerOwnReadyText.gameObject.activeSelf == false)
            {
                GameObject.FindObjectOfType<RoomWaitManager>().players[PlayerNum].PlayerOwnReadyText.gameObject.SetActive(true);
                GameObject.FindObjectOfType<RoomWaitManager>().players[PlayerNum].hasReady = true;
            }
            else
            {
                GameObject.FindObjectOfType<RoomWaitManager>().players[PlayerNum].PlayerOwnReadyText.gameObject.SetActive(false);
                GameObject.FindObjectOfType<RoomWaitManager>().players[PlayerNum].hasReady = false;
            }
           } 
         
         
    }

    [PunRPC]
    public void SetUIData(int i)
    {
        RoomWaitManager waitmanager = GameObject.FindObjectOfType<RoomWaitManager>();
        waitmanager.players[i] = this;
        PlayerNum = i;
        PlayerOwnScene = waitmanager.PlayerScenes[i];
        PlayerOwnNameText = waitmanager.PlayerNameTexts[i];
        PlayerOwnReadyText = waitmanager.ReadyTexts[i];
        PlayerOwnNameText.gameObject.SetActive(true);
        PlayerOwnNameText.text = this.GetComponent<PhotonView>().Owner.NickName;
       
        
    }

    [PunRPC]
    public void QuitButtonDeal()
    {
        RoomWaitManager waitmanager = GameObject.FindObjectOfType<RoomWaitManager>();
        waitmanager.players[PlayerNum] = null;
        PlayerOwnNameText.gameObject.SetActive(true);
        Destroy(gameObject);
    }


}
