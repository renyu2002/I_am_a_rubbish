using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreIcon : MonoBehaviour
{
    public Text timeText;
    public Text playernameText;
    public Text scoreText;
    public Text rankText;

    public void SetData(int rank,int score,string time,string name)
    {
        rankText.text = rank.ToString();
        scoreText.text = score.ToString();
        timeText.text = time;
        playernameText.text = name;
    }
}
