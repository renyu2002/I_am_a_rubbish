using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerScore : Singleton<PlayerScore>
{
    // Start is called before the first frame update
    public List<int> ScoreList;
    public List<int> RankList;
    public List<string> TimeList;
    public List<string> PlayerNameList;
    public GameObject PlayerScoreIcon;
    public Transform Scores;

    void Start()
    {
        ScoreList = new List<int>();
        RankList = new List<int>();
        TimeList = new List<string>();
        PlayerNameList = new List<string>();
        Scores = GameObject.FindObjectOfType<MainSceneUI>().GetComponent<MainSceneUI>().PlayerScoreHistory;
    }

    public void AddPlayerScore(int i,int score,string playername)
    {
        TimeList.Add(DateTime.Now.ToLocalTime().ToString("yyyy-MM-dd HH:mm:ss"));
        RankList.Add(i);
        ScoreList.Add(score);
        PlayerNameList.Add(playername);
    }

    public bool hasData()
    {
        return ScoreList.Count != 0;
    }

    public void UpdatePlayerScore()
    {
        // Scores = GameObject.FindGameObjectWithTag("SCORE").transform;
        Scores = GameObject.FindObjectOfType<MainSceneUI>().GetComponent<MainSceneUI>().PlayerScoreHistory;
        int len = RankList.Count;
        for(int i = 0; i < len ; i++)
        {
           GameObject tmp = Instantiate(PlayerScoreIcon);
           tmp.transform.SetParent(Scores);
            // SetData(int rank,int score,string time,string name)
           tmp.GetComponent<ScoreIcon>().SetData(RankList[i], ScoreList[i], TimeList[i], PlayerNameList[i]);
        }

    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
