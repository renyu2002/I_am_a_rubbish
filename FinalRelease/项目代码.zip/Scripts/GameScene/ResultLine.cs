using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Photon.Pun;

public class ResultLine : MonoBehaviour
{
    public Text PlayerNameText;
    public Text PlayerScoreText;
   
}
