using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Photon.Pun;
public class PlayerGame : MonoBehaviour
{
    [Header("---UIҪ��---")]
    public Button Choose_A;
    public Button Choose_B;
    public Button Choose_C;
    public Button Choose_D;
    public Button ConfirmButton;
    public Text QuestionText;
    public Text ChooseA_Text;
    public Text ChooseB_Text;
    public Text ChooseC_Text;
    public Text ChooseD_Text;
    public GameObject EndScene;
    public GameObject ResultScene;
    public Text Answertext;
    public Text Timetext;
    public string PlayerName;
    public int Answer_Num_tmp = -1;
    public int Answer_Num=-1;
    public int CurrentQuestionIndex = 0;
    public int Answer_Score;
    public int PlayerNum;

    [Header("---����UIҪ��---")]
    public Image PlayerHeadImage;
    public Text ScoreText;
    public Text NameText;
    

    [SerializeField] PhotonView pv;

    int questionNum = 1;

    // Start is called before the first frame update
    void Start()
    {
        
    }



    [PunRPC]
    void MakeAnswer(int i)
    {
        if (pv.IsMine)
        {
            bool isTrue = false;
            if (Answer_Num == i)
            {
                Answer_Score += 5;
                isTrue = true;
                Debug.Log("�ش���ȷ���ӷ�Ŷ");
            }
            else
            {
                Answer_Score += 0;
                Debug.Log("�ش���󣬵����۷�");

            }
            //ͬ��������ʾ������������ʷ��¼ͼ��
            //�ش�����õ�ǰѡ��ֵ
            //CurrentQuestionIndex++;
            //��ʷ��¼����
            CSVReader csvReader = GameObject.FindObjectOfType<CSVReader>();
            GameObject lastAnswerIcon = Instantiate(csvReader.HistoryIcon, csvReader.HistoryPar);
            lastAnswerIcon.GetComponent<QuestionIcon>().SetIconState(questionNum, isTrue);
            
            //������ʾ����
            ScoreText.text = Answer_Score.ToString();
            Answer_Num = -1;
            Answer_Num_tmp = -1; 
        }
        else
        {
            CSVReader csvReader = GameObject.FindObjectOfType<CSVReader>();
            if (Answer_Num == i)
            {
                csvReader.players[PlayerNum].Answer_Score += 5;
                Debug.Log("�ش���ȷ���ӷ�Ŷ");
            }
            else
            {
                csvReader.players[PlayerNum].Answer_Score += 0;
                Debug.Log("�ش���󣬵����۷�");

            }

            //CurrentQuestionIndex++;
            csvReader.players[PlayerNum].ScoreText.text = Answer_Score.ToString();
            //���·�����Ϣ
            //�ش�����õ�ǰѡ��ֵ
            csvReader.players[PlayerNum].Answer_Num = -1;
            csvReader.players[PlayerNum].Answer_Num_tmp = -1;
        }

        questionNum += 1;
    }
    [PunRPC]
    public void IncreaseIndex()
    {
        if (pv.IsMine)
        {
            CurrentQuestionIndex++;
        }
        else
        {
            CSVReader csvReader = GameObject.FindObjectOfType<CSVReader>();
            csvReader.players[PlayerNum].CurrentQuestionIndex++;
        }
    }

    [PunRPC]
    public void ChooseAnswer_A()
    {
        if (pv.IsMine)
        {
            Answer_Num_tmp = 1;        
        }
        else
        {
            GameObject.FindObjectOfType<CSVReader>().players[PlayerNum].Answer_Num_tmp = 1;   
        }
    }

    [PunRPC]
    public void ChooseAnswer_B()
    {
        if (pv.IsMine)
        {
            Answer_Num_tmp = 2;
        }
        else
        {
            GameObject.FindObjectOfType<CSVReader>().players[PlayerNum].Answer_Num_tmp = 2;
        }
    }
    [PunRPC]
    public void ChooseAnswer_C()
    {
        if (pv.IsMine)
        {
            Answer_Num_tmp = 3;
        }
        else
        {
            GameObject.FindObjectOfType<CSVReader>().players[PlayerNum].Answer_Num_tmp = 3;
        }
    }
    [PunRPC]
    public void ChooseAnswer_D()
    {
        if (pv.IsMine)
        {
            Answer_Num_tmp = 4;
        }
        else
        {
            GameObject.FindObjectOfType<CSVReader>().players[PlayerNum].Answer_Num_tmp = 4;
        }
    }
    [PunRPC]
    public void ChooseAnswer_Confirm()
    {
        if (pv.IsMine)
        {
            Answer_Num= Answer_Num_tmp;
        }
        else
        {
            GameObject.FindObjectOfType<CSVReader>().players[PlayerNum].Answer_Num = Answer_Num_tmp;
        }
    }

    [PunRPC]
    void SetUIData(int i)
    {
        CSVReader csvReader = GameObject.FindObjectOfType<CSVReader>();
        QuestionText = csvReader.QuestionText;
        ChooseA_Text = csvReader.ChooseA_Text;
        ChooseB_Text = csvReader.ChooseB_Text;
        ChooseC_Text = csvReader.ChooseC_Text;
        ChooseD_Text = csvReader.ChooseD_Text;
        Timetext = csvReader.TimeCountText;
        ResultScene = csvReader.AnswerScene;
        Answertext = csvReader.AnswerText;
        EndScene = csvReader.EndScene;
        csvReader.players[i] = this;
        PlayerHeadImage=csvReader.PlayerFrameImage[i];
        ScoreText=csvReader.PlayerScoreTexts[i];
        NameText=csvReader.PlayerNameTexts[i];
        PlayerNum = i;

    }
    [PunRPC]
    void ShowAnswerScene(int i)
    {
      

        ResultScene.SetActive(true);
        switch (i)
        {
            case 1:
                Answertext.text = "A";
                break;
            case 2:
                Answertext.text = "B";
                break;
            case 3:
                Answertext.text = "C";
                break;
            case 4:
                Answertext.text = "D";
                break;
            default:          
                break;

        }
    }

    [PunRPC]
    void HideAnswerScene()
    {
        if (!pv.IsMine)
            return;

        ResultScene.SetActive(false);
    }
  
    [PunRPC]
    void UpdateTimeText(float timer)
    {
        int target = (int)timer;
        Timetext.text = target.ToString();
    }

    [PunRPC]
    void EndGameUIShow()
    {
        if (!pv.IsMine)
           return;
        //��ֹ�ظ����ã�

        CSVReader csvReader = GameObject.FindObjectOfType<CSVReader>();
        EndScene.SetActive(true);
        /*List<PlayerGame> waitingplayers = new List<PlayerGame>();
        for (int i = 0; i < PhotonNetwork.CurrentRoom.PlayerCount; i++)
        {
            waitingplayers.Add(csvReader.players[i]);
            Debug.Log(csvReader.players[i]);
        }*/

        for(int i = PhotonNetwork.CurrentRoom.PlayerCount; i < 4; i++)
        {
            csvReader.EndLine[i].gameObject.SetActive(false);
        }

        var waitingplayers = GameObject.FindObjectsOfType<PlayerGame>();

        //�������������ʾ��ԭ���Ǽ����ĸ���ҵķ������жԱ�Ȼ������
        for (int i = 0; i < PhotonNetwork.CurrentRoom.MaxPlayers; i++)
        {
            int maxPoint = 0;
            PlayerGame maxPlayer = new PlayerGame();
            foreach (var tmp in waitingplayers)
            {
                Debug.Log("������ķ���Ϊ:" + tmp.Answer_Score.ToString());
                if (tmp.Answer_Score > maxPoint)
                {
                    maxPlayer = tmp;
                    maxPoint = tmp.Answer_Score;
                }
            }
            Debug.Log("������ֵΪ:"+maxPoint);
            csvReader.EndLine[i].PlayerNameText.text = (string)maxPlayer.GetComponent<PhotonView>().Owner.CustomProperties["PlayerLogName"];//.NickName;//maxPlayer.PlayerName;
            Debug.Log("�����(�Զ��壩Ϊ��" + maxPlayer.GetComponent<PhotonView>().Owner.CustomProperties["PlayerLogName"]);
            Debug.Log("�����(nick��Ϊ��" + maxPlayer.GetComponent<PhotonView>().Owner.NickName);
            csvReader.EndLine[i].PlayerScoreText.text = maxPoint.ToString();
            if (maxPlayer.GetComponent<PhotonView>().IsMine)
            {
                //��⵽Ϊ�Լ���������ʷ��¼
                PlayerScore.Instance.AddPlayerScore(i + 1, maxPoint, (string)maxPlayer.GetComponent<PhotonView>().Owner.CustomProperties["PlayerLogName"]);

            }
            maxPlayer.Answer_Score = -1;

        }
    }

    [PunRPC]
    void UpdateQuestionUI(int index)
    {
        CSVReader csvReader = GameObject.FindObjectOfType<CSVReader>();
     
        var qdata = csvReader.QuestionLine[index].Split(","[0]);
        if (qdata[0] != "")
        {
            Debug.Log(qdata);
            QuestionText.text = qdata[0];
            ChooseA_Text.text = qdata[1];
            ChooseB_Text.text = qdata[2];
            ChooseC_Text.text = qdata[3];
            ChooseD_Text.text = qdata[4];
        }
    }

 
}
