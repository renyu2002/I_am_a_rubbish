using System;
using System.Data;
using MySql.Data.MySqlClient;
using UnityEngine;
using System.Text;

public class SqlAccess
{
	public static MySqlConnection dbConnection;
	//���ֻ���ڱ��صĻ���дlocalhost�Ϳ��ԡ�
	// static string host = "localhost";  
	//����Ǿ���������ôд�ϱ����ľ�����IP
	static string host = "localhost";
	static string port = "3306";
	static string username = "root";
	static string pwd = "309483";
	static string database = "scores";

	public SqlAccess()
	{
		OpenSql();
	}

	/// <summary>
	/// �������ݿ�
	/// </summary>
	public static void OpenSql()
	{
		try
		{
			string connectionString = string.Format("server = {0};port={1};database = {2};user = {3};password = {4};", host, port, database, username, pwd);
			Debug.Log(connectionString);
			dbConnection = new MySqlConnection(connectionString);
			dbConnection.Open();
			Debug.Log("��������");
		}
		catch (Exception e)
		{
			throw new Exception("����������ʧ�ܣ������¼���Ƿ��MySql����" + e.Message.ToString());
		}
	}

	/// <summary>
	/// �ر����ݿ�����
	/// </summary>
	public void Close()
	{
		if (dbConnection != null)
		{
			dbConnection.Close();
			dbConnection.Dispose();
			dbConnection = null;
		}
	}

	/// <summary>
	/// ��ѯ
	/// </summary>
	/// <param name="tableName">����</param>
	/// <param name="items"></param>
	/// <param name="col">�ֶ���</param>
	/// <param name="operation">�����</param>
	/// <param name="values">�ֶ�ֵ</param>
	/// <returns>DataSet</returns>
	public DataSet SelectWhere(string tableName, string[] items, string[] col, string[] operation, string[] values)
	{

		if (col.Length != operation.Length || operation.Length != values.Length)
			throw new Exception("col.Length != operation.Length != values.Length");

		StringBuilder query = new StringBuilder();
		query.Append("SELECT ");
		query.Append(items[0]);

		for (int i = 1; i < items.Length; ++i)
		{
			query.Append(", ");
			query.Append(items[i]);
		}

		query.Append(" FROM ");
		query.Append(tableName);
		query.Append(" WHERE 1=1");

		for (int i = 0; i < col.Length; ++i)
		{
			query.Append(" AND ");
			query.Append(col[i]);
			query.Append(operation[i]);
			query.Append("'");
			query.Append(values[0]);
			query.Append("' ");
		}
		Debug.Log(query.ToString());
		return ExecuteQuery(query.ToString());
	}

	/// <summary>
	/// ִ��sql���
	/// </summary>
	/// <param name="sqlString">sql���</param>
	/// <returns></returns>
	public static DataSet ExecuteQuery(string sqlString)
	{
		if (dbConnection.State == ConnectionState.Open)
		{
			DataSet ds = new DataSet();
			try
			{
				MySqlDataAdapter da = new MySqlDataAdapter(sqlString, dbConnection);
				da.Fill(ds);
			}
			catch (Exception ee)
			{
				throw new Exception("SQL:" + sqlString + "/n" + ee.Message.ToString());
			}
			finally
			{
			}
			return ds;
		}
		return null;
	}
}
