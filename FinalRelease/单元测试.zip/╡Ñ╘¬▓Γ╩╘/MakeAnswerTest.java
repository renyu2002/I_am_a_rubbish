import org.junit.Test;
import org.junit.Before;
import org.junit.After;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import static org.junit.Assert.assertEquals;/**
 * MaskAnswer Tester.
 *
 * @author <Authors name>
 * @since <pre>May 30, 2022</pre>
 * @version 1.0
 */
public class MakeAnswerTest {
    PrintStream console = null;
    ByteArrayOutputStream bytes = null;
    int answerNum;
    list<String> answers=list.of("answer1","answer2","answer3","answer4");
    int score;
    String answer;
    
    @Before
    public void before() throws Exception {
        bytes = new ByteArrayOutputStream();
        console = System.out;
        System.setOut(new PrintStream(bytes));
    }

    @After
    public void after() throws Exception {
        System.setOut(console);
    }
    /**
     *
     * Method: Judge(int answerNum,list<String> answers,int score,String answer)
     *
     */
    @Test
    public void testJudge() throws Exception {
        assertEquals(0,new MakeAnswer().Judge(3, answers,5,"answer1"));
        assertEquals(0,new MakeAnswer().Judge(3, answers,5,"answer2"));
        assertEquals(5,new MakeAnswer().Judge(3, answers,5,"answer3"));
        assertEquals(0,new MakeAnswer().Judge(3, answers,5,"answer4"));
        assertEquals(100,new MakeAnswer().Judge(1, answers,100,"answer1"));
    }
} 
