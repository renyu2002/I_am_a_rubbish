using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Photon.Pun;

public class MainSceneUI : MonoBehaviourPunCallbacks
{

    


    [Header("---���ý���---")]
    [SerializeField] GameObject SetScene;
    [SerializeField] Button SetSceneOpenSwitch;
    [SerializeField] Button SetSceneCloseSwitch;

    [Header("---��ҽ���--- ")]
    [SerializeField] GameObject PlayerScene;
    [SerializeField] GameObject PScene_1;
    [SerializeField] GameObject PScene_2;
    [SerializeField] Button PlayerSceneOpenSwitch;
    [SerializeField] Button PlayerSceneCloseSwitch;
    [SerializeField] Button PSceneSwitch_1;
    [SerializeField] Button PSceneSwitch_2;

    [Header("---����������---")]
    [SerializeField] GameObject RoomEnterScene;
    [SerializeField] Button EnterSceneSwitch;
    [SerializeField] Button EnterSceneCloseSwitch;

    [Header("---���䴴������---")]
    [SerializeField] GameObject RoomSetScene;
    [SerializeField] Button RoomSetEnterSwitch;
    [SerializeField] Button RoomSetCloseSwitch;


    [Header("---������Ϸ---")]
    [SerializeField] Button QuickGameSwitch;

    [Header("---��Ϸ������---")]
    [SerializeField] Launcher RoomLauncher;

    public override void OnEnable()
    {
        base.OnEnable();
        Initiation();
    }

    void Start()
    {
      // PhotonNetwork.ConnectUsingSettings();
    }


    /// <summary>
    /// ��ʼ������ʼ����ui�İ�ť�߼�
    /// </summary>
    void Initiation()
    {

        /* ���水ť�嵥
      * SetSceneOpenSwitch;
      * SetSceneCloseSwitch;
      * PlayerSceneOpenSwitch
      * PlayerSceneCloseSwitch
      * PSceneSwitch_1
      * PSceneSwitch_2
      * EnterSceneSwitch
      * EnterSceneCloseSwitch
      * RoomSetEnterSwitch
      * RoomSetCloseSwitch
      * QuickGameSwitch
      */

        /*�����԰�ť�嵥
         * quickgameswitch
         * 
         */
        QuickGameSwitch.onClick.AddListener(
            delegate ()
            {
             //   PhotonNetwork.JoinOrCreateRoom("Room", new Photon.Realtime.RoomOptions() { MaxPlayers = 4 },default);
            });

        SetSceneOpenSwitch.onClick.AddListener(
            delegate ()
            {
                SetScene.SetActive(true);
            });

        SetSceneCloseSwitch.onClick.AddListener(
            delegate ()
            {
                SetScene.SetActive(false);
            });

        PlayerSceneOpenSwitch.onClick.AddListener(
            delegate ()
            {
                PlayerScene.SetActive(true);
            });

        PlayerSceneCloseSwitch.onClick.AddListener(
            delegate ()
            {
                PlayerScene.SetActive(false);

                ColorBlock cb = PSceneSwitch_1.colors;
                cb.normalColor = new Color(0.18f, 0.215f, 0.258f);
                PSceneSwitch_1.colors = cb;
                PSceneSwitch_2.colors = cb;
            });

        PSceneSwitch_1.onClick.AddListener(
            delegate ()
            {
                PScene_1.SetActive(true);
                PScene_2.SetActive(false);

                ColorBlock cb = PSceneSwitch_1.colors;
                PSceneSwitch_2.colors = cb;
                cb.normalColor = new Color(0.75f, 0.75f, 0.75f);
                PSceneSwitch_1.colors = cb;
            });

        PSceneSwitch_2.onClick.AddListener(
            delegate ()
            {
                PScene_1.SetActive(false);
                PScene_2.SetActive(true);

                ColorBlock cb = PSceneSwitch_2.colors;
                PSceneSwitch_1.colors = cb;
                cb.normalColor = new Color(0.75f, 0.75f, 0.75f);
                PSceneSwitch_2.colors = cb;
            });


       EnterSceneSwitch.onClick.AddListener(
            delegate ()
            {
               RoomEnterScene.SetActive(true);
            });

        EnterSceneCloseSwitch.onClick.AddListener(
           delegate ()
           {
               RoomEnterScene.SetActive(false);
           });

       
         RoomSetEnterSwitch.onClick.AddListener(
           delegate ()
           {
               RoomSetScene.SetActive(true);
           });

        RoomSetCloseSwitch.onClick.AddListener(
          delegate ()
          {
              RoomSetScene.SetActive(false);
              RoomLauncher.ExitRoomBuildScene();
          });


    }

}
