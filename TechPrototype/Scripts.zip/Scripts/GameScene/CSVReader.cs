using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Photon.Pun;
public class CSVReader : MonoBehaviour
{

    [SerializeField] GameObject PlayerGameSample;
    [SerializeField] Canvas dialogUI;
    [Header("---ѡ��---")]
    [SerializeField] Button Choose_A;
    [SerializeField] Button Choose_B;
    [SerializeField] Button Choose_C;
    [SerializeField] Button Choose_D;
    [SerializeField] Button ConfirmButton;



    [Header("---�ı�---")]
    [SerializeField] public Text QuestionText;
    [SerializeField] public Text ChooseA_Text;
    [SerializeField] public Text ChooseB_Text;
    [SerializeField] public Text ChooseC_Text;
    [SerializeField] public Text ChooseD_Text;

    [Header("---����ļ�---")]
    [SerializeField] TextAsset QuestionFile;


    int ZoneLength = 0;
    public string[] QuestionZone = new string[12];//�����������12������
    public int[] QuestionZone_Startline = new int[12];
    public int[] QuestionZone_Endline = new int[12];
     /// <summary>
    /// ��Ӧcsv�ı��ж�Ӧ���ݵĸ���
    /// </summary>
    /// 
    [Header("---��Ӧ����---")]
    [SerializeField] int QuestionCell= 0;
    [SerializeField] int A_AnswerCell = 1;
    [SerializeField] int B_AnswerCell = 2;
    [SerializeField] int C_AnswerCell = 3;
    [SerializeField] int D_AnswerCell = 4;
    [SerializeField] int R_AnswerCell = 5;

    [Header("---����б�---")]

    public PlayerGame[] players;
    public int AnswerNum = 0;
    public int[] playerAnswer;
    public int NowQuestionNum = 0;

    [Header("---���UI---")]
    public Transform[] PlayerIcons;
    public Image[] PlayerFrameImage;
    public Text[] PlayerScoreTexts;
    public Text[] PlayerNameTexts;
    public GameObject AnswerScene;
    public Text AnswerText;
    public Text TimeCountText;

    [Header("---�������---")]
    public GameObject EndScene;
    public ResultLine[] EndLine;
    public GameObject EndButton;

    [Header("---��ʷ����---")]
    public Transform HistoryPar;
    public GameObject HistoryIcon;



    [SerializeField] public string[] QuestionLine;

    
    int index = -1;//һ��Ϊ�˷�������ʱ����
    Color selectedColor = new Color(0, 0, 1, 0.8f);     // ������Ϊ�˷�����ѡ����ɫ
    Color normalColor = new Color(0.117f, 0.117f, 0.78f, 0.586f);


    void ReturnZoneQuestionData()
    {

    }


    void ReturnRandomQuestionData()
    {
        int target = ReturnRandomQuestion();
    }




    void ReturnQuestionData(int i)
    {

    }


    //������Ŀ�Ƿ񱻴�������Ŀ�ɷ���������

    /// <summary>
    /// suibainshenme
    /// </summary>
    /// <returns></returns>
    bool QuestionNumHasCreated()
    {
        Debug.Log("��ǰ��Ŀ״̬");
        Debug.Log((int)PhotonNetwork.CurrentRoom.CustomProperties["NowQuestionID"]);
        return (int)PhotonNetwork.CurrentRoom.CustomProperties["NowQuestionID"] != -1;
    }

   
    private void Start()
    {
        Initiation();
        int i = PhotonNetwork.CurrentRoom.PlayerCount;
        GameObject newPlayer = PhotonNetwork.Instantiate(PlayerGameSample.name, new Vector3(0, 0, 0), Quaternion.identity);
        PhotonNetwork.LocalPlayer.NickName = "NO." + i.ToString();
        localPlayerCreated = true;
        newPlayer.GetComponent<PhotonView>().RPC("SetUIData", RpcTarget.All, i - 1);

       /* Debug.Log((int)PhotonNetwork.CurrentRoom.CustomProperties["NowQuestionID"]);
        Debug.Log("try:");
        Debug.Log((int)PhotonNetwork.CurrentRoom.CustomProperties["QuestionNumInRoom"]);*/
        //StartCoroutine(nameof(SingleQuestionCoroutine));"QuestionNumInRoom"


        //���ｫ������ұ���Ҹ��Ӹ����õ���
        int num = PhotonNetwork.CurrentRoom.PlayerCount;
        for (int tmp1 = 0; tmp1 < 4; tmp1++)
        {
            if (tmp1 >= num)
            {
                PlayerIcons[tmp1].gameObject.SetActive(false);
            }
        }

        StartCoroutine(SingleQuestionCoroutine());
    }

    IEnumerator SingleQuestionCoroutine()
    {
        /* ��һ�������ɶ�Ӧ��ţ�����������ҵĿͻ���ͬ����ʾһ������
         * �ڶ����������������ȷ�Ϻ������������ҵĻش𣨻ش�ͬ��������ͬ����
         * ��������������ƣ�10s����֮�����������ҵĻش�
         * ���Ĳ���ͬ����ҵĻ��棬��ʾ�����˵�ѡ��������ȷ�𰸽��
         * ���岽����������仯�������仯
         * ����������ʼ��һ����Ĵ���
         */
        //��д���򵥵������Ŀ��ͬ����Ч��
        /* if (PhotonNetwork.CurrentRoom.CustomProperties.ContainsKey("QuestionNumInRoom"))
         {
             Debug.Log("��ȡ���˷������Ŀ��������ϢŶ");
         }
         else
         {
             Debug.Log("û�ܻ�ȡ���˷������Ŀ��������ϢŶ");
         }

         if (PhotonNetwork.CurrentRoom.CustomProperties.ContainsKey("NowQuestionID")){
             Debug.Log("��ȡ���˷���ĵ�ǰ���˼��������ϢŶ");
         }
         else
         {
             Debug.Log("δ�ܻ�ȡ���˷���ĵ�ǰ���˼��������ϢŶ");
         }
        */
        float timer0 = 12f;
        var playerwaits_0 = GameObject.FindObjectsOfType<PlayerGame>();
        while (timer0 > 0)
        {
            timer0 -= Time.deltaTime;
            foreach (var tmp in playerwaits_0)
            {
                tmp.GetComponent<PhotonView>().RPC("UpdateTimeText", RpcTarget.All, timer0);
            }
            yield return null;
        }

        if (PhotonNetwork.CurrentRoom.CustomProperties.ContainsKey("QuestionNumInRoom"))
        {
           // Debug.Log("��Ϸ��Ŀ����Ϊ��" + (int)PhotonNetwork.CurrentRoom.CustomProperties["QuestionNumInRoom"]);

            while (NowQuestionNum < (int)PhotonNetwork.CurrentRoom.CustomProperties["QuestionNumInRoom"])
            {
                var playerwaits = GameObject.FindObjectsOfType<PlayerGame>();

                //��ס�𰸽���
                foreach (var tmp in playerwaits)
                {
                    tmp.GetComponent<PhotonView>().RPC("HideAnswerScene", RpcTarget.All);       
                }


                NowQuestionNum++;
                int targetNum = -1;
                if (PhotonNetwork.IsMasterClient)
                {
                    targetNum = ReturnRandomQuestion();
                    PhotonNetwork.CurrentRoom.CustomProperties["NowQuestionID"] = targetNum;
                   
                    //��֡��⣬����Ҷ�Ӧ��ui��ֵ��˽�з������
                }
                /*  else
                  {
                      Debug.Log("���ڵȴ���Ŀ����");

                      yield return new WaitUntil(QuestionNumHasCreated);
                      Debug.Log("��Ŀ�Ѿ�������");
                      targetNum = (int)PhotonNetwork.CurrentRoom.CustomProperties["NowQuestionID"];
                  }*/


                /*  var qdata = QuestionLine[targetNum].Split(","[0]);
                  Debug.Log(qdata);
                  QuestionText.text = qdata[QuestionCell];
                  ChooseA_Text.text = qdata[A_AnswerCell];
                  ChooseB_Text.text = qdata[B_AnswerCell];
                  ChooseC_Text.text = qdata[C_AnswerCell];
                  ChooseD_Text.text = qdata[D_AnswerCell];*/

                yield return new WaitUntil(()=> (int)PhotonNetwork.CurrentRoom.CustomProperties["NowQuestionID"]!=-1);
                
                var playerwaits_1 = GameObject.FindObjectsOfType<PlayerGame>();
                targetNum = (int)PhotonNetwork.CurrentRoom.CustomProperties["NowQuestionID"];
                foreach (var tmp in playerwaits_1)
                {
                    tmp.GetComponent<PhotonView>().RPC("UpdateQuestionUI", RpcTarget.All, targetNum);
                }

               
                var qdata = QuestionLine[targetNum].Split(","[0]);
                int result = int.Parse(qdata[R_AnswerCell]);

                float timer1 = 12f;
                while (timer1 > 0)
                {
                    timer1 -= Time.deltaTime;
                    foreach (var tmp in playerwaits)
                    {
                        tmp.GetComponent<PhotonView>().RPC("UpdateTimeText", RpcTarget.All, timer1);
                    }
                    yield return null;
                }
                //����͵���12��
                //yield return new WaitForSeconds(12f);//�ȴ�15�룬�ȴ��������ѡ��
                                                     //return null;
                
                //�жϴ�+��ʾ��
                foreach (var tmp in playerwaits)
                {
                    tmp.GetComponent<PhotonView>().RPC("MakeAnswer", RpcTarget.All, result);
                    tmp.GetComponent<PhotonView>().RPC("ShowAnswerScene", RpcTarget.All, result);
                }

                if (PhotonNetwork.IsMasterClient)
                {
                    PhotonNetwork.CurrentRoom.CustomProperties["NowQuestionID"] = -1;
                }


                // yield return new WaitForSeconds(3f);//�ȴ�15�룬�ȴ��������ѡ��
                timer1 = 3f;
                while (timer1 > 0)
                {
                    timer1 -= Time.deltaTime;
                    foreach (var tmp in playerwaits)
                    {
                        tmp.GetComponent<PhotonView>().RPC("UpdateTimeText", RpcTarget.All, timer1);
                    }
                    yield return null;
                }
                //�������������������ѡ���ж��Ƿ�����һ��
                ColorBlock bg = Choose_A.colors;
                bg.normalColor = normalColor;
                Choose_A.colors = bg;
                Choose_B.colors = bg;
                Choose_C.colors = bg;
                Choose_D.colors = bg;

            }
            //��Ŀ����ȫ����ʾ���,��ʾ���������Լ�����
            //����Ҳ��Ҫ��һ��prcͬ��
            //GameEnd();

            yield return new WaitForSeconds(3f);

            for(int i = 0; i < PhotonNetwork.CurrentRoom.PlayerCount; i++)
            {
                players[i].GetComponent<PhotonView>().RPC("EndGameUIShow", RpcTarget.All);
            }
            

        }
        else
        {
            Debug.Log("δ�ܻ�ȡ�����Զ�������");
        }
       
    }

    public void GameEnd()
    {
        EndScene.SetActive(true);
        List<PlayerGame> waitingplayers=new List<PlayerGame>();
        for (int i = 0; i < PhotonNetwork.CurrentRoom.MaxPlayers; i++){
            waitingplayers.Add(players[i]);
        }

        //�������������ʾ��ԭ���Ǽ����ĸ���ҵķ������жԱ�Ȼ������
        for(int i =0; i < PhotonNetwork.CurrentRoom.MaxPlayers;i++)
        {
            int maxPoint = 0;
            PlayerGame maxPlayer = new PlayerGame();
            foreach(var tmp in waitingplayers)
            {
                if (tmp.Answer_Score > maxPoint)
                {
                    maxPlayer = tmp;
                    maxPoint = tmp.Answer_Score;
                }
            }
            EndLine[i].PlayerNameText.text = maxPlayer.PlayerName;
            EndLine[i].PlayerScoreText.text = maxPoint.ToString();
            waitingplayers.Remove(maxPlayer);

        }
    }

    


   

    protected void Awake()
    {
      
        players = new PlayerGame[PhotonNetwork.CurrentRoom.MaxPlayers];
        playerAnswer = new int[PhotonNetwork.CurrentRoom.MaxPlayers];
      
    }

    /// <summary>
    /// ���������Ŀ�к�
    /// </summary>
    /// <returns></returns>
    int ReturnRandomQuestion()
    {
        int target = Random.Range(2, QuestionLine.Length-1);
        bool can = false;//����Ƿ���������
        while (!can)
        {
            can = true;
            for (int i = 0; i < ZoneLength; i++)
            {
                if(target == QuestionZone_Startline[i] - 1)
                {
                    can = false;
                    target = Random.Range(2, QuestionLine.Length);
                }
            }
        }

        return target;
    }


    /// <summary>
    /// ����ĳ�����������Ŀ�к�,����Ϊ������
    /// </summary>
    /// <param name="ZoneName"></param>
    /// <returns></returns>
    int ReturnZoneRandomQuestion(string ZoneName)
    {
        int zoneNum = ReturnZoneNum(ZoneName);
        int target = Random.Range(QuestionZone_Startline[zoneNum], QuestionZone_Endline[zoneNum]);
        return target;
    }


    int ReturnZoneNum(string checkZoneName)
    {
        for(int i = 0; i < QuestionZone.Length; i++)
        {
            if (QuestionZone[i] == checkZoneName)
            {
                return i;
            }
        }

        Debug.Log("δ�鵽�ùؼ���");
        return 0;//Ĭ�ϲ��ҵ�һ������
    }


    public void Choose_A_Deal()
    {
        var players = GameObject.FindObjectsOfType<PlayerGame>();
        // int PlayerNum = 1;
        foreach (var tmp in players)
        {
            if (tmp.GetComponent<PhotonView>().IsMine)
            {
                tmp.GetComponent<PhotonView>().RPC("ChooseAnswer_A", RpcTarget.All);
                //hasReady = !hasReady;
                //PlayerOwnReadyText.gameObject.SetActive(hasReady);
            }
            // PlayerNum += 1;

        }

        ColorBlock bg = Choose_A.colors;
        Choose_B.colors = bg;
        Choose_C.colors = bg;
        Choose_D.colors = bg;
        bg.normalColor = selectedColor;
        Choose_A.colors = bg;
    }

    public void Choose_B_Deal()
    {
        var players = GameObject.FindObjectsOfType<PlayerGame>();
        // int PlayerNum = 1;
        foreach (var tmp in players)
        {
            if (tmp.GetComponent<PhotonView>().IsMine)
            {
                tmp.GetComponent<PhotonView>().RPC("ChooseAnswer_B", RpcTarget.All);
                //hasReady = !hasReady;
                //PlayerOwnReadyText.gameObject.SetActive(hasReady);
            }
            // PlayerNum += 1;

        }

        ColorBlock bg = Choose_B.colors;
        Choose_A.colors = bg;
        Choose_C.colors = bg;
        Choose_D.colors = bg;
        bg.normalColor = selectedColor;
        Choose_B.colors = bg;
    }

    public void Choose_C_Deal()
    {
        var players = GameObject.FindObjectsOfType<PlayerGame>();
        // int PlayerNum = 1;
        foreach (var tmp in players)
        {
            if (tmp.GetComponent<PhotonView>().IsMine)
            {
                tmp.GetComponent<PhotonView>().RPC("ChooseAnswer_C", RpcTarget.All);
                //hasReady = !hasReady;
                //PlayerOwnReadyText.gameObject.SetActive(hasReady);
            }
            // PlayerNum += 1;

        }

        ColorBlock bg = Choose_C.colors;
        Choose_A.colors = bg;
        Choose_B.colors = bg;
        Choose_D.colors = bg;
        bg.normalColor = selectedColor;
        Choose_C.colors = bg;
    }

    public void Choose_D_Deal()
    {


        var players = GameObject.FindObjectsOfType<PlayerGame>();
        // int PlayerNum = 1;
        foreach (var tmp in players)
        {
            if (tmp.GetComponent<PhotonView>().IsMine)
            {
                tmp.GetComponent<PhotonView>().RPC("ChooseAnswer_D", RpcTarget.All);
                //hasReady = !hasReady;
                //PlayerOwnReadyText.gameObject.SetActive(hasReady);
            }
            // PlayerNum += 1;

        }

        ColorBlock bg = Choose_D.colors;
        Choose_A.colors = bg;
        Choose_B.colors = bg;
        Choose_C.colors = bg;
        bg.normalColor = selectedColor;
        Choose_D.colors = bg;
    }

    public void Choose_Confirm_Deal()
    {
        var players = GameObject.FindObjectsOfType<PlayerGame>();
        // int PlayerNum = 1;
        foreach (var tmp in players)
        {
            if (tmp.GetComponent<PhotonView>().IsMine)
            {
                tmp.GetComponent<PhotonView>().RPC("ChooseAnswer_Confirm", RpcTarget.All);
                //hasReady = !hasReady;
                //PlayerOwnReadyText.gameObject.SetActive(hasReady);
            }
            // PlayerNum += 1;

        }


    }


    public void Button_Quit()
    {
        PhotonNetwork.LeaveRoom();
        PhotonNetwork.LoadLevel(0);
    }

    public void Button_End()
    {
        PhotonNetwork.LeaveRoom();
        PhotonNetwork.LoadLevel(0);
    }

    /// <summary>
    /// ���ú���ÿ���Ի�����ʼ�кͽ�����
    /// </summary>
    void Initiation()
    {
        int nowZone = 0;
        QuestionLine = QuestionFile.text.Split("\n"[0]);

        for (int i = 1; i <= QuestionLine.Length - 1; i++)
        {
            var tmp = QuestionLine[i].Split(","[0]);

            for (int j = 0; j < tmp.Length; j++)
            {
                Debug.Log("��ǰ����Ϣ:" + tmp[j]);
            }

            Debug.Log("��ʼ�ж��Ƿ�Ϊ������");
            if (tmp[0].Length<=3&&tmp[0]!="")//֤���Ǳ�����Ŀ���͵���
            {
                ZoneLength += 1;
                QuestionZone[nowZone] = tmp[0];
                QuestionZone_Startline[nowZone] = i + 1;//��һ�п�ʼΪ������������
                if (nowZone != 0)
                {
                    QuestionZone_Endline[nowZone - 1] = i - 1;
                }
                nowZone++;
            }
        }

        QuestionZone_Endline[nowZone - 1] = QuestionLine.Length - 2;//Ϊ���һ��questionzone�Ľ����и�ֵ
        
 }




    bool localPlayerCreated = false;
    private void Update()
    {
        var playergames = GameObject.FindObjectsOfType<PlayerGame>();
        //��֡��⣬����Ҷ�Ӧ��ui��ֵ��˽�з������
        for (int i = 0; i <playergames.Length; i++)
        {
            if (playergames[i].GetComponent<PhotonView>().Owner != PhotonNetwork.LocalPlayer)
            {
                if (playergames[i].GetComponent<PhotonView>().Owner.CustomProperties.ContainsKey("PlayerNum"))
                {
                    int j = (int)playergames[i].GetComponent<PhotonView>().Owner.CustomProperties["PlayerNum"];
                    Debug.Log(playergames[i].GetComponent<PhotonView>().Owner.CustomProperties["PlayerNum"]);
                    if (players[j] == null)
                    {
                        players[j] = playergames[i];
                        playergames[i].GetComponent<PhotonView>().RPC("SetUIData", RpcTarget.All, j);

                    }
                }
            }
        }
    }


}
