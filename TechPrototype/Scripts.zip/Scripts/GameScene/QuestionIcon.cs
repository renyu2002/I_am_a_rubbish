using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class QuestionIcon : MonoBehaviour
{
    [SerializeField] Text QuestionNumText;
    [SerializeField] Color32 Color_Right = new Color32(0, 255, 0,255);
    [SerializeField] Color32 Color_False = new Color32(255, 0, 0, 255);

    public void SetIconState(int i , bool tmp)
    {
        QuestionNumText.text = i.ToString();
        if (tmp)
        {
            GetComponent<Image>().color = Color_Right;
        }
        else
        {
            GetComponent<Image>().color = Color_False;
        }
    }


}
