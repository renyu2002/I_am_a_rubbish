using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Photon.Pun;

public class RoomWaitManager : MonoBehaviourPunCallbacks
{

    [Header("--�������ui����--")]
    //����Ϊ�ģ����ݷ�����Ϣ����scenes
    public GameObject PlayerSimple;
    public GameObject[] PlayerScenes;
    //public Button[] ReadyButtons;
    public Text[] PlayerNameTexts;
    public Text[] ReadyTexts;

  /*  [Header("--��Ҹ������--")]
    public GameObject PlayerOwnScene;
    public Text PlayerOwnNameText;
    public Text PlayerOwnReadyText;
    public bool hasReady=false;*/
    [Header("--��Ҷ���--")]
    public PlayerWait[] players= new PlayerWait[4];
    [Header("--�������--")]
    public Button StartGame;
    public Button ReadyGame;
    public Button SetGame;
    public Button QuitGame;

    private void Start()
    {
        UIInitiation();
    }


    bool localPlayerCreated = false;
    public void Update()
    {


        var playerwaits = GameObject.FindObjectsOfType<PlayerWait>();
        //��֡��⣬����Ҷ�Ӧ��ui��ֵ��˽�з������
        for(int i = 0; i < playerwaits.Length;i++){
            
            if (playerwaits[i].GetComponent<PhotonView>().Owner != PhotonNetwork.LocalPlayer)
            {
                if (playerwaits[i].GetComponent<PhotonView>().Owner.CustomProperties.ContainsKey("PlayerNum"))
                {
                    int j = (int)playerwaits[i].GetComponent<PhotonView>().Owner.CustomProperties["PlayerNum"];
                    Debug.Log(playerwaits[i].GetComponent<PhotonView>().Owner.CustomProperties["PlayerNum"]);
                    if (players[j] == null)
                    {
                        players[j] = playerwaits[i];
                        playerwaits[i].GetComponent<PhotonView>().RPC("SetUIData", RpcTarget.All, j);

                    }
                }
            }
        }

      
    }




    public void UIInitiation()
    {
        int maxplayers= PhotonNetwork.CurrentRoom.MaxPlayers;
        int nowplayernum = 0;
        //��������������ö�Ӧ��ҿ�
        foreach(var tmp in PlayerScenes)
        {
            if (nowplayernum>=maxplayers)
            {
                tmp.SetActive(false);
            }
            else
            {
                tmp.SetActive(true);
            }
            nowplayernum += 1;
        }
        int i = PhotonNetwork.CurrentRoom.PlayerCount;
        GameObject newPlayer = PhotonNetwork.Instantiate(PlayerSimple.name, new Vector3(0, 0, 0), Quaternion.identity);
        PhotonNetwork.LocalPlayer.NickName = "NO." + i.ToString();
        localPlayerCreated = true;
        newPlayer.GetComponent<PhotonView>().RPC("SetUIData", RpcTarget.All, i - 1);


    }

    public void EnterGameButtonDeal()
    {
        if (!PhotonNetwork.IsMasterClient)//ֻ�з������Կ�ʼ��Ϸ
        {
            return;
        }


        var players = GameObject.FindObjectsOfType<PlayerWait>();
        int num = 0;
        foreach (var tmp in players)
        {
            if (tmp.hasReady)
            {
                num++;
            }
        }
        Debug.Log(num);
        Debug.Log(PhotonNetwork.CurrentRoom.MaxPlayers);
        if (num == PhotonNetwork.CurrentRoom.MaxPlayers)
        {
            foreach (var tmp in players)
            {
                if (tmp.GetComponent<PhotonView>().IsMine)
                {
                    tmp.GetComponent<PhotonView>().RPC("EnterGame", RpcTarget.All);
                }
            }
        }
    }


    //��������˳���״̬
    public void QuitGameButtonDeal()
    {
        PhotonNetwork.LeaveRoom();
        var players = GameObject.FindObjectsOfType<PlayerWait>();
        // int PlayerNum = 1;
        foreach (var tmp in players)
        {
            if (tmp.GetComponent<PhotonView>().IsMine)
            {
                tmp.GetComponent<PhotonView>().RPC("QuitButtonDeal", RpcTarget.All);
            }
        }

        PhotonNetwork.LoadLevel(0);
    }

    public void ReadyGameButtonDeal()
    {
        var players = GameObject.FindObjectsOfType<PlayerWait>();
       // int PlayerNum = 1;
        foreach (var tmp in players)
        {
            if (tmp.GetComponent<PhotonView>().IsMine)
            {
                tmp.GetComponent<PhotonView>().RPC("ReadyButtonDeal", RpcTarget.All);
                //hasReady = !hasReady;
                //PlayerOwnReadyText.gameObject.SetActive(hasReady);
            }
           // PlayerNum += 1;
         
        }
       
    }


   
    
}
