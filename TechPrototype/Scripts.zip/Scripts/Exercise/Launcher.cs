using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Photon.Pun;
using Photon.Realtime;


using Hashtable = ExitGames.Client.Photon.Hashtable;//�����ò���hashֱ��ת��
public class Launcher : MonoBehaviourPunCallbacks
{
 
    // Start is called before the first frame update
    [SerializeField] Button QuickButton;



    [Header("---���䴴������---")]
    //������Ҫ���ӵ���ֵ��ͬʱ���ó�ʼֵ
    Level RoomLevel=Level.NONE;
    byte PlayerMaxNum=0;
    int QuestionNum=0;

    [SerializeField] Button CreateRoomButton;

    [SerializeField] Button LevelButton_Easy;
    [SerializeField] Button LevelButton_Normal;
    [SerializeField] Button LevelButton_Difficult;

    [SerializeField] Button PlayerMaxNum_2;
    [SerializeField] Button PlayerMaxNum_3;
    [SerializeField] Button PlayerMaxNum_4;

    [SerializeField] Button QuestionNum_10;
    [SerializeField] Button QuestionNum_15;
    [SerializeField] Button QuestionNum_20;
    [SerializeField] Button QuestionNum_25;


    [Header("---����������---")]
    public string TargetRoomName = "";
    public Room SelectedRoom;
    [SerializeField] Button JoinRoomButton;
    [SerializeField] Transform RoomParent;
    [SerializeField] GameObject RoomPrefab;



    /// <summary>
    /// ��ʼ�����䴴�������еİ�������
    /// </summary>
    void Initiation_RoomBuildScene()
    {
        LevelButton_Easy.onClick.AddListener(delegate ()
       {
           RoomLevel = Level.EASY;
           Debug.Log("�Ѷ�ѡ��" + "��");

           ColorBlock cb = LevelButton_Easy.colors;
           LevelButton_Normal.colors = cb;
           LevelButton_Difficult.colors = cb;
           cb.normalColor = Color.white;
           LevelButton_Easy.colors = cb;
       });

        LevelButton_Normal.onClick.AddListener(delegate ()
        {
            RoomLevel = Level.NORMAL;
            Debug.Log("�Ѷ�ѡ��" + "��ͨ");

            ColorBlock cb = LevelButton_Normal.colors;
            LevelButton_Easy.colors = cb;
            LevelButton_Difficult.colors = cb;
            cb.normalColor = Color.white;
            LevelButton_Normal.colors = cb;
        });

        LevelButton_Difficult.onClick.AddListener(delegate ()
        {
            RoomLevel = Level.DIFFICULT;
            Debug.Log("�Ѷ�ѡ��" + "����");

            ColorBlock cb = LevelButton_Difficult.colors;
            LevelButton_Easy.colors = cb;
            LevelButton_Normal.colors = cb;
            cb.normalColor = Color.white;
            LevelButton_Difficult.colors = cb;
        });

        PlayerMaxNum_2.onClick.AddListener(delegate ()
        {
            PlayerMaxNum = 2;
            Debug.Log("���������" + "2");

            ColorBlock cb = PlayerMaxNum_2.colors;
            PlayerMaxNum_3.colors = cb;
            PlayerMaxNum_4.colors = cb;
            cb.normalColor = Color.white;
            PlayerMaxNum_2.colors = cb;
        });

        PlayerMaxNum_3.onClick.AddListener(delegate ()
        {
            PlayerMaxNum = 3;
            Debug.Log("���������" + "3");

            ColorBlock cb = PlayerMaxNum_3.colors;
            PlayerMaxNum_2.colors = cb;
            PlayerMaxNum_4.colors = cb;
            cb.normalColor = Color.white;
            PlayerMaxNum_3.colors = cb;
        });

        PlayerMaxNum_4.onClick.AddListener(delegate ()
        {
            PlayerMaxNum = 4;
            Debug.Log("���������" + "4");

            ColorBlock cb = PlayerMaxNum_4.colors;
            PlayerMaxNum_2.colors = cb;
            PlayerMaxNum_3.colors = cb;
            cb.normalColor = Color.white;
            PlayerMaxNum_4.colors = cb;
        });

        QuestionNum_10.onClick.AddListener(delegate ()
        {
            QuestionNum = 10;
            Debug.Log("����������" + "10");

            ColorBlock cb = QuestionNum_10.colors;
            QuestionNum_15.colors = cb;
            QuestionNum_20.colors = cb;
            QuestionNum_25.colors = cb;
            cb.normalColor = Color.white;
            QuestionNum_10.colors = cb;
        });

        QuestionNum_15.onClick.AddListener(delegate ()
        {
            QuestionNum = 15;
            Debug.Log("����������" + "15");

            ColorBlock cb = QuestionNum_15.colors;
            QuestionNum_10.colors = cb;
            QuestionNum_20.colors = cb;
            QuestionNum_25.colors = cb;
            cb.normalColor = Color.white;
            QuestionNum_15.colors = cb;
        });

        QuestionNum_20.onClick.AddListener(delegate ()
        {
            QuestionNum = 20;
            Debug.Log("����������" + "20");

            ColorBlock cb = QuestionNum_20.colors;
            QuestionNum_10.colors = cb;
            QuestionNum_15.colors = cb;
            QuestionNum_25.colors = cb;
            cb.normalColor = Color.white;
            QuestionNum_20.colors = cb;
        });

        QuestionNum_25.onClick.AddListener(delegate ()
        {
            QuestionNum = 25;
            Debug.Log("����������" + "25");

            ColorBlock cb = QuestionNum_25.colors;
            QuestionNum_10.colors = cb;
            QuestionNum_15.colors = cb;
            QuestionNum_20.colors = cb;
            cb.normalColor = Color.white;
            QuestionNum_25.colors = cb;
        });
    }

  

    void Start()
    {
        Initiation_RoomBuildScene();
        PhotonNetwork.ConnectUsingSettings();

        QuickButton.onClick.AddListener(delegate ()
        {
            PhotonNetwork.JoinOrCreateRoom("Room", new Photon.Realtime.RoomOptions() { MaxPlayers = 4 }, default);
            //���ﻹ����һ��ͦ���ӵ����Ҫ�����ɷ���
        });

        CreateRoomButton.onClick.AddListener(delegate ()
        {
            //�������ɷ���ѡ���Ҫ�����ɷ���

            //Ϊ�������ӵ��Զ�������
            Hashtable t = new Hashtable() {
            { "RoomLevel", RoomLevel },
            { "QuestionNum", QuestionNum },
            {"NowQuestionID",-1 },//ͬ����ʾ��ͬ��Ŀ��ʹ��
            {"QuestionNumInRoom",QuestionNum}
         };

         //ָ�������пɷ��ʵķ������Ե�����
         string[] roomPropsInLobby = { "RoomLevel", "QuestionNum" };
         
         RoomOptions options = new RoomOptions();

         options.CustomRoomProperties = t;
        
         options.CustomRoomPropertiesForLobby = roomPropsInLobby;//�������������Ҫ
         options.MaxPlayers = PlayerMaxNum;
         //���4λ��������
        string RoomName = "";
        int tmp = Random.Range(0, 10000);
        RoomName = tmp.ToString(); 
        PhotonNetwork.CreateRoom(RoomName,options,default);
        });

        JoinRoomButton.onClick.AddListener(delegate ()
        {
            //���ݵ�ǰѡ��ķ��䰴ť���뷿��
            if (TargetRoomName != "")
            {
                PhotonNetwork.JoinRoom(TargetRoomName);
            }
            else
            {
                PhotonNetwork.JoinRandomRoom();
            }
        });
    }

    public override void OnConnectedToMaster()
    {
        base.OnConnectedToMaster();
        Debug.Log("���ӷ������ɹ�");
        PhotonNetwork.JoinLobby();//����Ӧ���ǽ��������
     //   PhotonNetwork.JoinOrCreateRoom("Room", new Photon.Realtime.RoomOptions() { MaxPlayers = 4 }, default);
    }

    public override void OnCreatedRoom()
    {
        base.OnCreatedRoom();
        Debug.Log("���췿��ɹ�");
    }

    public override void OnRoomPropertiesUpdate(Hashtable propertiesThatChanged)
    {
        base.OnRoomPropertiesUpdate(propertiesThatChanged);
        if (propertiesThatChanged.ContainsKey("RoomLevel"))
        {
            Debug.Log(propertiesThatChanged["RoomLevel"]);
        }
        if (propertiesThatChanged.ContainsKey("QuestionNum"))
        {
            Debug.Log(propertiesThatChanged["QuestionNum"]);
        }


    }

    public override void OnJoinedRoom()
    {
        Hashtable t = new Hashtable() {
            { "PlayerNum", PhotonNetwork.CurrentRoom.PlayerCount-1 }
         };
        PhotonNetwork.LocalPlayer.SetCustomProperties(t);

        Debug.Log("��������Զ������Գɹ�");
        base.OnJoinedRoom();
        PhotonNetwork.LoadLevel(1);
        Debug.Log("���뷿��ɹ�");
    
    }

 

    public override void OnRoomListUpdate(List<RoomInfo> roomList)
    {

        for(int i = 0; i < RoomParent.childCount; i++)
        {
            Destroy(RoomParent.GetChild(i).gameObject);
        }

        for (int i = 0; i < RoomParent.childCount; i++)
        {
            if (RoomParent.GetChild(i).GetComponent<WaitingRoom>().RoomNumberText.text == roomList[i].Name)
            {
                Destroy(RoomParent.GetChild(i).gameObject);
            }

            if (roomList[i].PlayerCount == 0)
            {
                roomList.Remove(roomList[i]);
            }
        }
        // base.OnRoomListUpdate(roomList);
        foreach (var room in roomList)
        {
            if (room.MaxPlayers != 0)
            {
                GameObject newRoom = Instantiate(RoomPrefab, RoomParent.position, Quaternion.identity);
                // newRoom.GetComponent<Room>().RoomNumberText.text = room.GetHashCode();
                //�������room�����⸳ֵ��newRoom�Ĵ�����ֵ
                WaitingRoom target = newRoom.GetComponent<WaitingRoom>();


                target.RoomNum = int.Parse(room.Name);
                target.MaxPlayerNum = room.MaxPlayers;
                target.NowPlayerNum = room.PlayerCount;

                if (room.CustomProperties.ContainsKey("RoomLevel"))
                {
                    // Debug.Log(temp);
                    target.QuestionLevel = (Level)room.CustomProperties["RoomLevel"];//��ǿ��ת����һ��
                    Debug.Log("��ȡroomlevel�ɹ�");
                }
                else
                {
                    Debug.Log("��ȡroomlevelʧ��");
                }

                if (room.CustomProperties.ContainsKey("QuestionNum"))
                {
                    // Debug.Log(temp);
                    target.QuestionNum = (int)room.CustomProperties["QuestionNum"];//��ǿ��ת����һ��
                    Debug.Log("��ȡquestionnum�ɹ�");
                }
                else
                {
                    Debug.Log("��ȡquestionnumʧ��");
                }

                newRoom.transform.SetParent(RoomParent);
                //Debug.Log(room.CustomProperties);
            }
        }
    }

    // ����MainSceneUI���ڴ����������ر�ʱ���ã���������ֵ�밴ť��ɫ�ָ�Ĭ��ֵ
    public void ExitRoomBuildScene()
    {
        RoomLevel = Level.NONE;
        PlayerMaxNum = 0;
        QuestionNum = 0;

        ColorBlock cb = LevelButton_Easy.colors;
        cb.normalColor = Color.black;
        LevelButton_Easy.colors = cb;
        LevelButton_Normal.colors = cb;
        LevelButton_Difficult.colors = cb;
        PlayerMaxNum_2.colors = cb;
        PlayerMaxNum_3.colors = cb;
        PlayerMaxNum_4.colors = cb;
        QuestionNum_10.colors = cb;
        QuestionNum_15.colors = cb;
        QuestionNum_20.colors = cb;
        QuestionNum_25.colors = cb;
    }

}
