using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public enum Level
{
    NONE,
    EASY,
    DIFFICULT,
    NORMAL
}
public class WaitingRoom : MonoBehaviour
{
    // Start is called before the first frame update
    [Header("---�ı�����---")]
    public Text RoomNumberText;
    [SerializeField] Text NowPlayerNumText;
    [SerializeField] Text MaxPlayerNumText;
    [SerializeField] Text QuestionLevelText;
    [SerializeField] Text QuestionNumText;

    [Header("---��ֵ����---")]
    public int RoomNum;//������
    public int NowPlayerNum;
    public int MaxPlayerNum;
    public Level QuestionLevel;
    public int QuestionNum;

    private void Update()
    {
        DataUpdate();
    }

    private void OnEnable()
    {
        this.gameObject.GetComponent<Button>().onClick.AddListener(delegate()
        {
            GameObject laun = GameObject.Find("NetWorkLauncher");
            Debug.Log(laun);
            laun.GetComponent<Launcher>().TargetRoomName = RoomNum.ToString();
            Debug.Log("ѡ����" + RoomNum + "�ŷ���");
        });
    }

    void DataUpdate()
    {
        RoomNumberText.text = RoomNum.ToString();
        NowPlayerNumText.text = NowPlayerNum.ToString();
        MaxPlayerNumText.text = MaxPlayerNum.ToString();
        QuestionNumText.text = QuestionNum.ToString();
        string level;
        if (QuestionLevel == Level.EASY)
        {
            level = "EASY";
        }
        else if (QuestionLevel == Level.NORMAL)
        {
            level = "NORMAL";
        }
        else
        {
            level = "DIFFICULT";
        }
        QuestionLevelText.text = level;
    }
}
